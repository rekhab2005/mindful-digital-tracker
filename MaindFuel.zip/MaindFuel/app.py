# app.py

from flask import Flask, render_template, request, redirect, url_for
import os
import matplotlib
matplotlib.use('Agg')  # Prevent GUI issues
import matplotlib.pyplot as plt
import numpy as np

app = Flask(__name__)

# -------------------------------
# OOP – Encapsulation
# -------------------------------
class MotivationTracker:
    def __init__(self):
        self.__entries = []  # private list

    def add_entry(self, text, rating):
        self.__entries.append((text, rating))

    def get_entries(self):
        return self.__entries

tracker = MotivationTracker()
FILENAME = "mindfuel.txt"

# -------------------------------
# File handling
# -------------------------------
def save_entries():
    try:
        with open(FILENAME, "w") as f:
            for e in tracker.get_entries():
                f.write(f"{e[0]} | {e[1]}\n")
    except Exception as e:
        print("Error saving file:", e)

def load_entries():
    if os.path.exists(FILENAME):
        try:
            with open(FILENAME, "r") as f:
                for line in f:
                    parts = line.strip().split(" | ")
                    if len(parts) == 2:
                        tracker.add_entry(parts[0], int(parts[1]))
        except Exception as e:
            print("Error reading file:", e)

load_entries()

# -------------------------------
# Routes
# -------------------------------
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        text = request.form["text"]
        try:
            rating = int(request.form["rating"])
            if rating < 1 or rating > 10:
                raise ValueError
        except:
            return "Invalid rating! Must be 1–10."
        tracker.add_entry(text, rating)
        save_entries()
        return redirect(url_for("index"))

    entries = tracker.get_entries()
    return render_template("index.html", entries=entries)

@app.route("/plot.png")
def plot_png():
    entries = tracker.get_entries()
    if not entries:
        return "No data to plot."
    ratings = [e[1] for e in entries]
    x = np.arange(len(ratings))
    plt.figure(figsize=(6,4))
    plt.plot(x, ratings, marker="o", linestyle='-', color='blue')
    plt.title("Motivation Trend")
    plt.xlabel("Entry Number")
    plt.ylabel("Rating (1–10)")
    plt.grid(True)
    plt.tight_layout()
    if not os.path.exists("static"):
        os.makedirs("static")
    plt.savefig("static/plot.png")
    plt.close()
    return redirect("/static/plot.png")

# -------------------------------
# Run app
# -------------------------------
if __name__ == "__main__":
    app.run(debug=True)
